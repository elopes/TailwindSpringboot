package com.enlopes.TailwindSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TailwindSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TailwindSpringbootApplication.class, args);
	}

}
