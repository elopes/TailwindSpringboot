package com.enlopes.TailwindSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TailwindSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
